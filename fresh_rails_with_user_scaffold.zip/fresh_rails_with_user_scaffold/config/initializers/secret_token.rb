# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
FreshRailsWithUserModelScaffold::Application.config.secret_token = '9303b65af9792f3c86cc1adf6469807821214cf2ffdbfa740992f90e875f5d317b93a660afac97444d80f4b886b9af6c1d5657451047c6317b4fce71b78117e9'
